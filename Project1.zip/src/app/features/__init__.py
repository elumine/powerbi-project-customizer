"""Feature-sliced application modules."""

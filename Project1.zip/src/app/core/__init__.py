"""Core application logic."""
